/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema1;

//Paso 1. importar la funcionalidad para generar datos aleatorios

public class Ej03Matrices {

    public static void main(String[] args) {
	//Paso 2. iniciar el generador aleatorio     
	 
        //Paso 3. definir la matriz de enteros de tamaño 10x10 e iniciarla con nros. aleatorios 
    
        //Paso 4. mostrar el contenido de la matriz en consola
    
        //Paso 5. calcular e informar la suma de todos los elementos almacenados entre las filas 2 y 9 y las columnas 0 y 3
    
        //Paso 6. generar un vector de 10 posiciones donde cada posición i contiene la suma de la columna i de la matriz 
	//   luego de generado, imprimir el vector

        //Paso 7. lea un valor entero e indique si se encuentra o no en la matriz. En caso de encontrarse indique su ubicación (fila y columna)
        //   y en caso contrario imprima "No se encontró el elemento".

    }
}
