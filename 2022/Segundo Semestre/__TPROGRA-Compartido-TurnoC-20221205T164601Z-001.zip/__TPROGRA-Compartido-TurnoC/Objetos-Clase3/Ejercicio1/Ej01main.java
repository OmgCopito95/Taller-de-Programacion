/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema3;

import PaqueteLectura.Lector;

/**
 *
 * @author Adrian
 */
public class Ej01main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Ingrese color relleno/color linea");
       // String colorR= Lector.leerString();
       // String colorL= Lector.leerString();
        Triangulo t = new Triangulo(10,10,10,Lector.leerString(),Lector.leerString());
        System.out.println("Perimetro " +t.calcularPerimetro());
        System.out.println("Area " +t.calcularArea());
        
    }
    
}
