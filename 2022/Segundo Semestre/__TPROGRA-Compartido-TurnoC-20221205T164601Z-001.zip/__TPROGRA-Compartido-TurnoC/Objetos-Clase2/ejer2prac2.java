/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema2;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author alumnos
 */

public class ejer2prac2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Persona[] personas=new Persona[15];
        int diml=0;
        int edad,dni;
        String nombre;
        edad=GeneradorAleatorio.generarInt(80);
        while((edad!=0)&&(diml<15)){
            nombre=GeneradorAleatorio.generarString(10);
            dni=GeneradorAleatorio.generarInt(150000);
            personas[diml]= new Persona(nombre,dni,edad);
            diml++;
            edad=GeneradorAleatorio.generarInt(150);

        }
        
        int cant65=0;
        
        Persona pmin=new Persona();
        pmin.setDNI(999999);
        int x;
        for(x=0;x<diml;x++){
            //INCISO A
            if(personas[x].getEdad()>65){
                cant65++;
            }         
            if(personas[x].getDNI()<pmin.getDNI()){
               /*pmin.setDNI(personas[x].getDNI());
               pmin.setEdad(personas[x].getEdad());
               pmin.setNombre(personas[x].getNombre());*/
               
               pmin=personas[x];
            }
        

        }
        System.out.println("La cantidad de personas mayores a 65 son: "+cant65);
        System.out.println(pmin.toString());
    }
}
